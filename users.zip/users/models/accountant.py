from odoo import fields, models

class Accountant(models.Model):
    _name = "lms.accountant"
    _description = "Accountant"
    _inherits  = {"res.users": "user_id"}

    user_id = fields.Many2one("res.users", string="User", required=True, ondelete="cascade")
