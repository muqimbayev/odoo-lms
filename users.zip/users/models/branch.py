from odoo import fields, models

class Branch(models.Model):
    _name = "lms.branch"
    _description = "Branch"

    name = fields.Char(string="Name")
    manager_id = fields.Many2one("lms.manager", required=True, string="Manager")
    address = fields.Text(string="Address")
    group_ids = fields.One2many("lms.group", inverse_name="branch_id")
    count_students = fields.Integer(string="Count students", compute="_compute_count_student")
    