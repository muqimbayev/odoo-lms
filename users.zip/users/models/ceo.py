from odoo import fields, models


class CEO(models.Model):
    _name = "lms.ceo"
    _description = "CEO"
    _inherits = {"res.users": "user_id"}

    user_id = fields.Many2one("res.users", string="User", required=True, ondelete="cascade")
