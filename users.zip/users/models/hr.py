from odoo import fields, models


class HR(models.Model):
    _name = "lms.hr.manager"
    _description = "HR Manager"
    _inherits = {"res.users": "user_id"}

    user_id = fields.Many2one("res.users", string="User", required=True, ondelete="cascade")
    