from odoo import fields, models

class Manager(models.Model):
    _name = "lms.manager"
    _description = "Manager"
    _inherits = {"res.users": "user_id"}

    user_id = fields.Many2one("res.users", string="User", required=True, ondelete="cascade")
    branch_id = fields.Many2one("lms.branch", string="Filial", required=True)