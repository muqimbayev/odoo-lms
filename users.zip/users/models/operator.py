from odoo import fields, models


class Operator(models.Model):
    _name = "lms.operator"
    _inherits = {"res.users": "user_id"}

    user_id = fields.Many2one(comodel_name="res.users", string="User", required=True, ondelete="cascade")
    branch_id = fields.Many2one("lms.branch", required=True, string="Branch")
    # payment_ids = fields.One2many("lms.payment")
    


