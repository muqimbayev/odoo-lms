from odoo import fields, models


class Students(models.Model):
    _name = "lms.students"

    _inherits = {"res.users": "user_id"}

    user_id = fields.Many2one(comodel_name="res.users", string="User", required=True, ondelete="cascade")
    group_ids = fields.Many2many(comodel_name="lms.group", string="group")
    # certification_ids = fields.One2many(comodel_name="lms.student_certification")
    # payment_ids = fields.One2many(comodel_name="lms.payment")
    branch_ids = fields.Many2many(comodel_name="lms.branch", compute="_compute_branch_ids")
    






