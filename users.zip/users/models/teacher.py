from odoo import fields, models, api

class Subjects(models.Model):
    _name = "lms.subjects"
    _description = "Subjects"

class Certifications(models.Model):
    _name = "lms.certifications"
    _description = "Certifications"

    name = fields.Char(string="Name", required=True)
    degree = fields.Char(string="Degree")
    given_date = fields.Date(string="given date")
    validity_period = fields.Float(string="validity period", default=0, required=True) #Agar 0 bo'lsa amal qilish muddati cheksiz bo'ladi
    end_date = fields.Date(string="end date", compute="_compute_end_date")


class Teacher(models.Model):
   _name = "lms.teacher"
   _inherits = {"res.users": "user_id"}
   
   user_id = fields.Many2one("res.users", string="User", required=True, ondelete="cascade")
   branch_id = fields.Many2one("lms.branch", required=True, string="Branch")
   subject_ids = fields.Many2many(comodel_name="lsm.subjects", required=True)
   certification_id = fields.Many2many(comodel_name="lms.certifications", string="Certification")
   department_id = fields.Many2one(comodel_name="lms.department", string="Department")
   postion_ids = fields.Many2many(comodel_name="lms.positions", string="Postion")
   salary = fields.Float(string="Salary")
#    payment_ids = fields.One2many(comodel_name="lms.payment")
   group_ids = fields.Many2many(comodel_name="lms.group")
   work_schedule = fields.Selection([('full_time', "Full time"), ("part_time", "Part time"), ("hourly", "Hourly")])





   



